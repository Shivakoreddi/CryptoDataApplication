
import json
import requests
import boto3

s3 = boto3.client('s3')
def __request(url):
    try:
        response = requests.get(url)
        content = json.loads(response.content.decode('utf-8'))
        return content
    except requests.exceptions.RequestException:
        raise ValueError(content)



def get_coins_market(base_url,vs_currency):
    """list all market data includes coins price,market cap,volume """
    """sample url : https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd"""
    api_url = '{0}coins/markets?vs_currency={1}'.format(base_url, vs_currency)
    return __request(api_url)

def lambda_handler(event=None,context=None):
    bucket = 'lambda-market-updates'
    base_url = "https://api.coingecko.com/api/v3/"
    cmkt_json = get_coins_market(base_url,'usd')

    filename = 'market_daily' + '.json'

    uploadByteStream = bytes(json.dumps(cmkt_json).encode('UTF-8'))
    s3.put_object(Bucket=bucket,Key=filename,Body=uploadByteStream)
    print('PUT-COMPLETE')



